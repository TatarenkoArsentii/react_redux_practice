import ACTION_TYPES from "../actions/actionsType";
const initialState = {
  value: 0,
  step: 1,
};
// eslint-disable-next-line
export default function (state = initialState, action) {

  switch (action.type) {
    case ACTION_TYPES.INCREMENT:
      return { ...state, value: state.value + 1};
    case ACTION_TYPES.DECREMENT:
      return { ...state, value: state.value - 1 };
    default:
      return state;
  }
  // if (action.type == "INCREMENT") value: value + 1;
  // return state;
}
