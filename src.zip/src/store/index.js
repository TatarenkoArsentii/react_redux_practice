import { createStore } from "redux";
import rootReducer from "../reducers";
// import { Reducer } from "redux";
// import ACTION_TYPES from "../actions/actionsType";
// const initialState = {
//   value: 0,
// };

// const reducer = (state = initialState, action) => {
//   switch (action.type) {
//     case ACTION_TYPES.INCREMENT:
//       return { value: state.value + 1 };
//     case ACTION_TYPES.DECREMENT:
//       return { value: state.value - 1 };
//     default:
//       return state;
//   }
//   // if (action.type == "INCREMENT") value: value + 1;
//   // return state;
// };

const store = createStore(rootReducer);
export default store;
